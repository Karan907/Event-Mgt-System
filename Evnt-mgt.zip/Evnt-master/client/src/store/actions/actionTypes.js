export const GET_EVENTS = 'GET_EVENTS';
export const ADD_EVENT = 'ADD_EVENT';
export const DELETE_EVENT = 'DELETE_EVENT';
export const EDIT_EVENT = 'EDIT_EVENT';
export const SELECT_DATE = 'SELECT_DATE';
export const SELECT_EVENT = 'SELECT_EVENT';
export const OPEN_PANEL = 'OPEN_PANEL';
export const CLOSE_PANEL = 'CLOSE_PANEL';
export const CHANGE_MODE = 'CHANGE_MODE';
export const SHOW_MESSAGE = 'SHOW_MESSAGE';
export const SIGN_UP = 'SIGN_UP';
export const SIGN_IN = 'SIGN_IN';
export const SIGN_OUT = 'SIGN_OUT';
export const LOADING = 'LOADING';
export const SET_CURRENT_USER = 'SET_CURRENT_USER';


